# Third-party patch data

The TeamSpeak 6 beta5.1, beta5, and beta4.1 addon-enabling patch offsets and bytes in `config/windows-x64.json` are derived from [Exopandora/TS6AddonInstaller](https://github.com/Exopandora/TS6AddonInstaller), distributed under the MIT License. The beta5 data was checked against [patches.json at commit 94ba4a3](https://github.com/Exopandora/TS6AddonInstaller/blob/94ba4a3bdbacc447f76bb7d52fb5eeb842e66ba3/src/main/resources/patches.json), included in TS6AddonInstaller 3.9.0. The separate native decibel and linear-gain limit changes were developed for this project. The notice below is included with the derived patch data.

MIT License

Copyright (c) [year] [fullname]

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
